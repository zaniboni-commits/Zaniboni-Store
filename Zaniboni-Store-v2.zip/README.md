# Zaniboni-Store

Site estático da Zaniboni-Store com categorias PS3 e PS2.

## Botão de instalação

No `index.html`, troque:

`https://SEU-LINK-MEDIAFIRE-AQUI`

pelo link do seu arquivo **PKG autorizado** hospedado no MediaFire.

## Importante sobre o PKG

O site HTML, sozinho, não vira automaticamente um aplicativo PKG de PS3. Um PKG instalável precisa ser construído como um pacote de aplicativo/homebrew compatível com PS3. Este projeto prepara o botão e o catálogo; depois você pode apontar o botão para o PKG hospedado por você.

Distribua apenas conteúdo que você tenha autorização para distribuir.
